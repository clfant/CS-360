package com.example.project2chrisfantoption1;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private GridView gridView;
    private Button addButton, deleteButton, editButton;
    private DatabaseHelper1 dbHelper;
    private InventoryAdapter gridAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventorylist);

        gridView = findViewById(R.id.gridView);
        addButton = findViewById(R.id.addButton);
        deleteButton = findViewById(R.id.deleteButton);
        editButton = findViewById(R.id.editButton);
        dbHelper = new DatabaseHelper1(this);

        // Retrieve items from the database and populate the grid
        updateGridView();

        // Handle item click in the grid view (for edit action)
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Handle item click (e.g., edit item)
                Item selectedItem = (Item) parent.getItemAtPosition(position);
                // Implement edit logic here
            }
        });

        // Handle "Add Item" button click
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add new item to the database and refresh the grid
                addItemToDatabase();
            }
        });

        // Handle "Delete" button click
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Delete selected item from the database and refresh the grid
                deleteSelectedItem();
            }
        });

        // Handle "Edit" button click
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement logic to handle edit action
            }
        });
    }

    private void updateGridView() {
        // Get all items from the database
        List<Item> itemList = dbHelper.getAllItems();

        // Create adapter and set it to GridView
        gridAdapter = new InventoryAdapter(this, itemList);
        gridView.setAdapter(gridAdapter);
    }

    private void addItemToDatabase() {
        // For demonstration purposes, let's add a dummy item
        String itemName = "New Item";
        String itemDescription = "Description of New Item";
        Item newItem = new Item(itemName, itemDescription);

        // Add item to the database
        dbHelper.addItem(newItem);

        // Show a toast message indicating success
        Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();

        // Update the grid view to reflect the changes
        updateGridView();
    }

    private void deleteSelectedItem() {
        // Get the selected item from the grid view
        Item selectedItem = (Item) gridView.getSelectedItem();
        if (selectedItem != null) {
            // Delete the selected item from the database
            dbHelper.deleteItem(selectedItem.getId());
            // Show a toast message indicating success
            Toast.makeText(this, "Item deleted successfully", Toast.LENGTH_SHORT).show();
            // Update the grid view to reflect the changes
            updateGridView();
        } else {
            // Show a toast message indicating no item is selected
            Toast.makeText(this, "No item selected for deletion", Toast.LENGTH_SHORT).show();
        }
    }
}












